// *****************************************************************************
// * This file is part of the FreeFileSync project. It is distributed under    *
// * GNU General Public License: https://www.gnu.org/licenses/gpl-3.0          *
// * Copyright (C) Zenju (zenju AT freefilesync DOT org) - All Rights Reserved *
// *****************************************************************************

#include "file_grid.h"
#include <set>
#include <wx/dc.h>
#include <wx/settings.h>
#include <zen/i18n.h>
#include <zen/file_error.h>
#include <zen/basic_math.h>
#include <zen/format_unit.h>
#include <zen/scope_guard.h>
#include <wx+/tooltip.h>
#include <wx+/rtl.h>
#include <wx+/dc.h>
#include <wx+/image_tools.h>
#include <wx+/image_resources.h>
#include "../base/file_hierarchy.h"

using namespace zen;
using namespace fff;


const wxEventType fff::EVENT_GRID_CHECK_ROWS     = wxNewEventType();
const wxEventType fff::EVENT_GRID_SYNC_DIRECTION = wxNewEventType();


namespace
{
//let's NOT create wxWidgets objects statically:
inline wxColor getColorOrange   () { return { 238, 201,   0 }; }
inline wxColor getColorGrey     () { return { 212, 208, 200 }; }
inline wxColor getColorYellow   () { return { 247, 252,  62 }; }
//inline wxColor getColorYellowLight() { return { 253, 252, 169 }; }
inline wxColor getColorCmpRed   () { return { 255, 185, 187 }; }
inline wxColor getColorSyncBlue () { return { 185, 188, 255 }; }
inline wxColor getColorSyncGreen() { return { 196, 255, 185 }; }
inline wxColor getColorNotActive() { return { 228, 228, 228 }; } //light grey
inline wxColor getColorGridLine () { return { 192, 192, 192 }; } //light grey

const size_t ROW_COUNT_IF_NO_DATA = 0;
const int FILE_GRID_GAP_SIZE_DIP = 2;

/*
class hierarchy:
                                GridDataBase
                                    /|\
                     ________________|________________
                    |                                |
               GridDataRim                           |
                   /|\                               |
          __________|_________                       |
         |                    |                      |
   GridDataLeft         GridDataRight          GridDataCenter
*/

std::pair<ptrdiff_t, ptrdiff_t> getVisibleRows(const Grid& grid) //returns range [from, to)
{
    const wxSize clientSize = grid.getMainWin().GetClientSize();
    if (clientSize.GetHeight() > 0)
    {
        const wxPoint topLeft = grid.CalcUnscrolledPosition(wxPoint(0, 0));
        const wxPoint bottom  = grid.CalcUnscrolledPosition(wxPoint(0, clientSize.GetHeight() - 1));

        const ptrdiff_t rowCount = grid.getRowCount();
        const ptrdiff_t rowFrom  = grid.getRowAtPos(topLeft.y); //return -1 for invalid position, rowCount if out of range
        const ptrdiff_t rowTo    = grid.getRowAtPos(bottom.y);
        if (rowFrom >= 0 && rowTo >= 0)
            return { rowFrom, std::min(rowTo + 1, rowCount) };
    }
    return {};
}


void fillBackgroundDefaultColorAlternating(wxDC& dc, const wxRect& rect, bool evenRowNumber)
{
    //alternate background color to improve readability (while lacking cell borders)
    if (!evenRowNumber)
    {
        //accessibility, support high-contrast schemes => work with user-defined background color!
        const auto backCol = wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW);

        auto incChannel = [](unsigned char c, int diff) { return static_cast<unsigned char>(std::max(0, std::min(255, c + diff))); };

        auto getAdjustedColor = [&](int diff)
        {
            return wxColor(incChannel(backCol.Red  (), diff),
                           incChannel(backCol.Green(), diff),
                           incChannel(backCol.Blue (), diff));
        };

        auto colorDist = [](const wxColor& lhs, const wxColor& rhs) //just some metric
        {
            return numeric::power<2>(static_cast<int>(lhs.Red  ()) - static_cast<int>(rhs.Red  ())) +
                   numeric::power<2>(static_cast<int>(lhs.Green()) - static_cast<int>(rhs.Green())) +
                   numeric::power<2>(static_cast<int>(lhs.Blue ()) - static_cast<int>(rhs.Blue ()));
        };

        const int signLevel = colorDist(backCol, *wxBLACK) < colorDist(backCol, *wxWHITE) ? 1 : -1; //brighten or darken

        const wxColor colOutter = getAdjustedColor(signLevel * 14); //just some very faint gradient to avoid visual distraction
        const wxColor colInner  = getAdjustedColor(signLevel * 11); //

        //clearArea(dc, rect, backColAlt);

        //add some nice background gradient
        wxRect rectUpper = rect;
        rectUpper.height /= 2;
        wxRect rectLower = rect;
        rectLower.y += rectUpper.height;
        rectLower.height -= rectUpper.height;
        dc.GradientFillLinear(rectUpper, colOutter, colInner, wxSOUTH);
        dc.GradientFillLinear(rectLower, colOutter, colInner, wxNORTH);
    }
    else
        clearArea(dc, rect, wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW));
}


class IconUpdater;
class GridEventManager;
class GridDataLeft;
class GridDataRight;

struct IconManager
{
    IconManager(GridDataLeft& provLeft, GridDataRight& provRight, IconBuffer::IconSize sz) :
        iconBuffer_(sz),
        dirIcon_        (IconBuffer::genericDirIcon (sz)),
        linkOverlayIcon_(IconBuffer::linkOverlayIcon(sz)),
        iconUpdater_(std::make_unique<IconUpdater>(provLeft, provRight, iconBuffer_)) {}

    void startIconUpdater();
    IconBuffer& refIconBuffer() { return iconBuffer_; }

    const wxBitmap& getGenericDirIcon () const { return dirIcon_;         }
    const wxBitmap& getLinkOverlayIcon() const { return linkOverlayIcon_; }

private:
    IconBuffer iconBuffer_;
    const wxBitmap dirIcon_;
    const wxBitmap linkOverlayIcon_;

    std::unique_ptr<IconUpdater> iconUpdater_; //bind ownership to GridDataRim<>!
};

//########################################################################################################

class GridDataBase : public GridData
{
public:
    GridDataBase(Grid& grid, const SharedRef<FileView>& gridDataView) : grid_(grid), gridDataView_(gridDataView) {}

    void holdOwnership(const std::shared_ptr<GridEventManager>& evtMgr) { evtMgr_ = evtMgr; }

    GridEventManager* getEventManager() { return evtMgr_.get(); }

    /**/  FileView& getDataView()       { return gridDataView_.ref(); }
    const FileView& getDataView() const { return gridDataView_.ref(); }

protected:
    /**/
    Grid& refGrid()       { return grid_; }
    const Grid& refGrid() const { return grid_; }

    const FileSystemObject* getFsObject(size_t row) const { return getDataView().getFsObject(row); }

private:
    size_t getRowCount() const override
    {
        if (gridDataView_.ref().rowsTotal() == 0)
            return ROW_COUNT_IF_NO_DATA;

        return gridDataView_.ref().rowsOnView();
        //return std::max(MIN_ROW_COUNT, gridDataView_ ? gridDataView_->rowsOnView() : 0);
    }

    std::shared_ptr<GridEventManager> evtMgr_;
    Grid& grid_;
    SharedRef<FileView> gridDataView_;
};

//########################################################################################################

template <SelectedSide side>
class GridDataRim : public GridDataBase
{
public:
    GridDataRim(const SharedRef<FileView>& gridDataView, Grid& grid) : GridDataBase(grid, gridDataView) {}

    void setIconManager(const std::shared_ptr<IconManager>& iconMgr) { iconMgr_ = iconMgr; }

    void setItemPathForm(ItemPathFormat fmt) { itemPathFormat_ = fmt; }

    void getUnbufferedIconsForPreload(std::vector<std::pair<ptrdiff_t, AbstractPath>>& newLoad) //return (priority, filepath) list
    {
        if (iconMgr_)
        {
            const auto& rowsOnScreen = getVisibleRows(refGrid());
            const ptrdiff_t visibleRowCount = rowsOnScreen.second - rowsOnScreen.first;

            //preload icons not yet on screen:
            const int preloadSize = 2 * std::max<ptrdiff_t>(20, visibleRowCount); //:= sum of lines above and below of visible range to preload
            //=> use full visible height to handle "next page" command and a minimum of 20 for excessive mouse wheel scrolls

            for (ptrdiff_t i = 0; i < preloadSize; ++i)
            {
                const ptrdiff_t currentRow = rowsOnScreen.first - (preloadSize + 1) / 2 + getAlternatingPos(i, visibleRowCount + preloadSize); //for odd preloadSize start one row earlier

                const IconInfo ii = getIconInfo(currentRow);
                if (ii.type == IconInfo::ICON_PATH)
                    if (!iconMgr_->refIconBuffer().readyForRetrieval(ii.fsObj->template getAbstractPath<side>()))
                        newLoad.emplace_back(i, ii.fsObj->template getAbstractPath<side>()); //insert least-important items on outer rim first
            }
        }
    }

    void updateNewAndGetUnbufferedIcons(std::vector<AbstractPath>& newLoad) //loads all not yet drawn icons
    {
        if (iconMgr_)
        {
            const auto& rowsOnScreen = getVisibleRows(refGrid());
            const ptrdiff_t visibleRowCount = rowsOnScreen.second - rowsOnScreen.first;

            //loop over all visible rows
            for (ptrdiff_t i = 0; i < visibleRowCount; ++i)
            {
                //alternate when adding rows: first, last, first + 1, last - 1 ...
                const ptrdiff_t currentRow = rowsOnScreen.first + getAlternatingPos(i, visibleRowCount);

                if (isFailedLoad(currentRow)) //find failed attempts to load icon
                    if (const IconInfo ii = getIconInfo(currentRow);
                        ii.type == IconInfo::ICON_PATH)
                    {
                        //test if they are already loaded in buffer:
                        if (iconMgr_->refIconBuffer().readyForRetrieval(ii.fsObj->template getAbstractPath<side>()))
                        {
                            //do a *full* refresh for *every* failed load to update partial DC updates while scrolling
                            refGrid().refreshCell(currentRow, static_cast<ColumnType>(ColumnTypeRim::ITEM_PATH));
                            setFailedLoad(currentRow, false);
                        }
                        else //not yet in buffer: mark for async. loading
                            newLoad.push_back(ii.fsObj->template getAbstractPath<side>());
                    }
            }
        }
    }

private:
    bool isFailedLoad(size_t row) const { return row < failedLoads_.size() ? failedLoads_[row] != 0 : false; }

    void setFailedLoad(size_t row, bool failed = true)
    {
        if (failedLoads_.size() != refGrid().getRowCount())
            failedLoads_.resize(refGrid().getRowCount());

        if (row < failedLoads_.size())
            failedLoads_[row] = failed;
    }

    //icon buffer will load reversely, i.e. if we want to go from inside out, we need to start from outside in
    static size_t getAlternatingPos(size_t pos, size_t total)
    {
        assert(pos < total);
        return pos % 2 == 0 ? pos / 2 : total - 1 - pos / 2;
    }

protected:
    void renderRowBackgound(wxDC& dc, const wxRect& rect, size_t row, bool enabled, bool selected) override
    {
        if (enabled && !selected)
        {
            if (const DisplayType dispTp = getRowDisplayType(row);
                dispTp == DisplayType::NORMAL)
                //alternate background color to improve readability (while lacking cell borders)
                fillBackgroundDefaultColorAlternating(dc, rect, row % 2 == 0);
            else
            {
                clearArea(dc, rect, getBackGroundColor(row));

                //draw horizontal border if required
                if (dispTp == getRowDisplayType(row + 1))
                {
                    wxDCPenChanger dummy2(dc, getColorGridLine());
                    dc.DrawLine(rect.GetBottomLeft(), rect.GetBottomRight() + wxPoint(1, 0));
                }
            }
        }
        else
            GridData::renderRowBackgound(dc, rect, row, enabled, enabled && selected);
    }

    wxColor getBackGroundColor(size_t row) const
    {
        //accessibility: always set both foreground AND background colors!
        // => harmonize with renderCell()!

        switch (getRowDisplayType(row))
        {
            case DisplayType::NORMAL:
                break;
            case DisplayType::FOLDER:
                return getColorGrey();
            case DisplayType::SYMLINK:
                return getColorOrange();
            case DisplayType::INACTIVE:
                return getColorNotActive();
        }
        return wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW);
    }

private:
    enum class DisplayType
    {
        NORMAL,
        FOLDER,
        SYMLINK,
        INACTIVE,
    };

    DisplayType getRowDisplayType(size_t row) const
    {
        const FileSystemObject* fsObj = getFsObject(row);
        if (!fsObj )
            return DisplayType::NORMAL;

        //mark filtered rows
        if (!fsObj->isActive())
            return DisplayType::INACTIVE;

        if (fsObj->isEmpty<side>()) //always show not existing files/dirs/symlinks as empty
            return DisplayType::NORMAL;

        DisplayType output = DisplayType::NORMAL;
        //mark directories and symlinks
        visitFSObject(*fsObj, [&](const FolderPair& folder) { output = DisplayType::FOLDER; },
        [](const FilePair& file) {},
        [&](const SymlinkPair& symlink) { output = DisplayType::SYMLINK; });

        return output;
    }

    std::wstring getValue(size_t row, ColumnType colType) const override
    {
        std::wstring value;
        if (const FileSystemObject* fsObj = getFsObject(row))
            if (!fsObj->isEmpty<side>())
                switch (static_cast<ColumnTypeRim>(colType))
                {
                    case ColumnTypeRim::ITEM_PATH:
                        switch (itemPathFormat_)
                        {
                            case ItemPathFormat::FULL_PATH:
                                return AFS::getDisplayPath(fsObj->getAbstractPath<side>());
                            case ItemPathFormat::RELATIVE_PATH:
                                return utfTo<std::wstring>(fsObj->getRelativePath<side>());
                            case ItemPathFormat::ITEM_NAME:
                                return utfTo<std::wstring>(fsObj->getItemName<side>());
                        }
                        assert(false);
                        break;

                    case ColumnTypeRim::SIZE:
                        visitFSObject(*fsObj, [&](const FolderPair& folder) { value = L"<" + _("Folder") + L">"; },
                        [&](const FilePair& file) { value = formatNumber(file.getFileSize<side>()); },
                        //[&](const FilePair& file) { value = utfTo<std::wstring>(file.getFileId<side>()); }, // -> test file id
                        [&](const SymlinkPair& symlink) { value = L"<" + _("Symlink") + L">"; });
                        break;

                    case ColumnTypeRim::DATE:
                        visitFSObject(*fsObj, [](const FolderPair& folder) {},
                        [&](const FilePair&       file) { value = formatUtcToLocalTime(file   .getLastWriteTime<side>()); },
                        [&](const SymlinkPair& symlink) { value = formatUtcToLocalTime(symlink.getLastWriteTime<side>()); });
                        break;

                    case ColumnTypeRim::EXTENSION:
                        visitFSObject(*fsObj, [](const FolderPair& folder) {},
                        [&](const FilePair&       file) { value = utfTo<std::wstring>(getFileExtension(file   .getItemName<side>())); },
                        [&](const SymlinkPair& symlink) { value = utfTo<std::wstring>(getFileExtension(symlink.getItemName<side>())); });
                        break;
                }
        return value;
    }

    void renderCell(wxDC& dc, const wxRect& rect, size_t row, ColumnType colType, bool enabled, bool selected, HoverArea rowHover) override
    {
        //-----------------------------------------------
        //don't forget: harmonize with getBestSize()!!!
        //-----------------------------------------------

        if (const FileView::PathDrawInfo pdi = getDataView().getDrawInfo(row);
            pdi.fsObj)
        {
            wxDCTextColourChanger textColor(dc);
            if (!pdi.fsObj->isActive())
                textColor.Set(wxSystemSettings::GetColour(wxSYS_COLOUR_GRAYTEXT));
            else if (getRowDisplayType(row) != DisplayType::NORMAL)
                textColor.Set(*wxBLACK); //accessibility: always set both foreground AND background colors!

            wxRect rectTmp = rect;

            switch (static_cast<ColumnTypeRim>(colType))
            {
                case ColumnTypeRim::ITEM_PATH:
                {
                    const bool isTopRow = row == refGrid().getTopRow();

                    std::wstring itemName;
                    if (!pdi.fsObj->isEmpty<side>())
                        itemName = utfTo<std::wstring>(pdi.fsObj->getItemName<side>());

                    std::vector<const ContainerObject*> parentComponents; //excluding leaf component
                    std::span<const unsigned char> pathDrawInfo; //including leaf component

                    switch (itemPathFormat_)
                    {
                        case ItemPathFormat::FULL_PATH:
                            for (const FileSystemObject* fsObj2 = pdi.fsObj;;)
                            {
                                const ContainerObject& parent = fsObj2->parent();
                                parentComponents.push_back(&parent);

                                fsObj2 = dynamic_cast<const FolderPair*>(&parent);
                                if (!fsObj2)
                                    break;
                            }
                            std::reverse(parentComponents.begin(), parentComponents.end());

                            assert(pdi.pathDrawInfo.size() == parentComponents.size() + 1);
                            pathDrawInfo = pdi.pathDrawInfo;
                            break;

                        case ItemPathFormat::RELATIVE_PATH:
                            for (const FileSystemObject* fsObj2 = pdi.fsObj;;)
                            {
                                const ContainerObject& parent = fsObj2->parent();

                                fsObj2 = dynamic_cast<const FolderPair*>(&parent);
                                if (!fsObj2)
                                    break;
                                parentComponents.push_back(&parent);
                            }
                            std::reverse(parentComponents.begin(), parentComponents.end());

                            assert(pdi.pathDrawInfo.size() == parentComponents.size() + 2);
                            if (!pdi.pathDrawInfo.empty())
                                pathDrawInfo = pdi.pathDrawInfo.subspan(1);
                            break;

                        case ItemPathFormat::ITEM_NAME:
                            assert(!pdi.pathDrawInfo.empty());
                            if (!pdi.pathDrawInfo.empty())
                                pathDrawInfo = pdi.pathDrawInfo.subspan(pdi.pathDrawInfo.size() - 1);
                            break;
                    }

                    /* Partitioning:
                        _________________________________________________________________
                        | (gap | component name | gap | dash)* | icon | gap | item name |
                        -----------------------------------------------------------------        */

                    //calculate parent component render details
                    std::vector<std::pair<std::wstring, wxSize>> parentNameExtents;
                    parentNameExtents.reserve(parentComponents.size());
                    int parentsRenderWidth = 0; //total width of rendering parent components
                    for (const ContainerObject* parent : parentComponents)
                    {
                        const FolderPair* folder = dynamic_cast<const FolderPair*>(parent);
                        std::wstring compName = folder ? utfTo<std::wstring>(folder->getItemName<side>()) :
                                                AFS::getDisplayPath(parent->getAbstractPath<side>());
                        const wxSize compExt = getTextExtentBuffered(dc, compName);

                        parentNameExtents.emplace_back(std::move(compName), compExt);
                        parentsRenderWidth += gridGap_ + compExt.GetWidth() + gridGap_ + compLineExtent_.GetWidth();
                    }

                    //limit space for parent components: prioritize item name rendering!
                    int itemRenderWidth = 0;
                    if (!itemName.empty())
                    {
                        if (iconMgr_)
                            itemRenderWidth += iconMgr_->refIconBuffer().getSize();
                        itemRenderWidth += gridGap_ + getTextExtentBuffered(dc, itemName).GetWidth();
                    }

                    wxRect rectParents = rectTmp;
                    rectParents.width = std::min(rectTmp.width - itemRenderWidth, parentsRenderWidth);

                    wxRect rectItem = rectTmp;
                    rectItem.x     += std::max(0, rectParents.width);
                    rectItem.width -= std::max(0, rectParents.width);


                    assert(pathDrawInfo.size() == parentComponents.size() + 1);
                    if (pathDrawInfo.size() == parentComponents.size() + 1 && rectParents.width > 0)
                    {
                        //clear background below components => harmonize with renderRowBackgound()
                        if (enabled && !selected) //clearArea() is surprisingly expensive => call just once!
                            clearArea(dc, rectParents, wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW));

                        wxDCPenChanger dummy(dc, wxPen(dc.GetTextForeground() /*treat component lines like text*/, compLineExtent_.GetHeight()));

                        auto itPdi = pathDrawInfo.begin();
                        for (const auto& [compName, compExt] : parentNameExtents)
                        {
                            rectParents.x     += gridGap_;
                            rectParents.width -= gridGap_;

                            if (rectParents.width <= 0)
                                break;

                            if (*itPdi & FileView::PathDrawInfo::DRAW_COMPONENT || isTopRow)
                                drawCellText(dc, rectParents, compName, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL, &compExt); //GridData::drawCellText()

                            rectParents.x     += compExt.GetWidth() + gridGap_;
                            rectParents.width -= compExt.GetWidth() + gridGap_;

                            if (rectParents.width <= 0)
                                break;

                            ++itPdi; //start drawing connections of *next* component

                            const wxPoint mid = rectParents.GetTopLeft() + wxPoint(0, rectParents.height / 2);

                            if (*itPdi & FileView::PathDrawInfo::CONNECT_PREV)
                                dc.DrawLine(rectParents.GetTopLeft(), mid);

                            if (*itPdi & FileView::PathDrawInfo::CONNECT_NEXT)             //for some (fucking) reason, drawing from bottom to top flips
                                dc.DrawLine(mid, rectParents.GetBottomLeft() + wxPoint(0, 1)); //our input points, so always draw top -> down

                            if (*itPdi & FileView::PathDrawInfo::DRAW_COMPONENT || isTopRow)
                                dc.DrawLine(mid, mid + wxPoint(compLineExtent_.GetWidth() +
                                                               //extend line to icon center in case icon is smaller than default
                                                               (itPdi == pathDrawInfo.end() - 1 && iconMgr_ && !itemName.empty() ?
                                                                iconMgr_->refIconBuffer().getSize() / 2 : 0), 0));

                            rectParents.x     += compLineExtent_.GetWidth();
                            rectParents.width -= compLineExtent_.GetWidth();
                        }
                    }

                    if (!itemName.empty())
                    {
                        if (iconMgr_) //draw file icon
                        {
                            if (parentComponents.empty())
                            {
                                rectItem.x     += gridGap_;
                                rectItem.width -= gridGap_;
                            }
                            if (rectItem.width > 0)
                            {
                                //whenever there's something new to render on screen, start up watching for failed icon drawing:
                                //=> ideally it would suffice to start watching only when scrolling grid or showing new grid content, but this solution is more robust
                                //and the icon updater will stop automatically when finished anyway
                                //Note: it's not sufficient to start up on failed icon loads only, since we support prefetching of not yet visible rows!!!
                                iconMgr_->startIconUpdater();

                                wxBitmap fileIcon;

                                const IconInfo ii = getIconInfo(row);
                                switch (ii.type)
                                {
                                    case IconInfo::FOLDER:
                                        fileIcon = iconMgr_->getGenericDirIcon();
                                        break;

                                    case IconInfo::ICON_PATH:
                                        if (std::optional<wxBitmap> tmpIco = iconMgr_->refIconBuffer().retrieveFileIcon(ii.fsObj->template getAbstractPath<side>()))
                                            fileIcon = *tmpIco;
                                        else
                                        {
                                            setFailedLoad(row); //save status of failed icon load -> used for async. icon loading
                                            //falsify only! we want to avoid writing incorrect success values when only partially updating the DC, e.g. when scrolling,
                                            //see repaint behavior of ::ScrollWindow() function!
                                            fileIcon = iconMgr_->refIconBuffer().getIconByExtension(ii.fsObj->template getItemName<side>()); //better than nothing
                                        }
                                        break;

                                    case IconInfo::EMPTY:
                                        break;
                                }

                                const int iconSize = iconMgr_->refIconBuffer().getSize();
                                if (fileIcon.IsOk())
                                {
                                    wxRect rectIcon = rectItem;
                                    rectIcon.width = iconSize; //support small thumbnail centering

                                    auto drawIcon = [&](const wxBitmap& icon)
                                    {
                                        if (pdi.fsObj->isActive())
                                            drawBitmapRtlNoMirror(dc, icon, rectIcon, wxALIGN_CENTER);
                                        else
                                            drawBitmapRtlNoMirror(dc, wxBitmap(icon.ConvertToImage().ConvertToGreyscale(1.0 / 3, 1.0 / 3, 1.0 / 3)), //treat all channels equally!
                                                                  rectIcon, wxALIGN_CENTER);
                                    };

                                    drawIcon(fileIcon);

                                    if (ii.drawAsLink)
                                        drawIcon(iconMgr_->getLinkOverlayIcon());
                                }
                                rectItem.x     += iconSize;
                                rectItem.width -= iconSize;
                            }
                        }

                        rectItem.x     += gridGap_;
                        rectItem.width -= gridGap_;

                        if (rectItem.width > 0)
                        {
                            const wxSize& itemExtent = getTextExtentBuffered(dc, itemName);
                            drawCellText(dc, rectItem, itemName, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL, &itemExtent);
                        }
                    }
                }
                break;

                case ColumnTypeRim::SIZE:
                    if (refGrid().GetLayoutDirection() != wxLayout_RightToLeft)
                    {
                        rectTmp.width -= gridGap_; //have file size right-justified (but don't change for RTL languages)
                        drawCellText(dc, rectTmp, getValue(row, colType), wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL);
                    }
                    else
                    {
                        rectTmp.x     += gridGap_;
                        rectTmp.width -= gridGap_;
                        drawCellText(dc, rectTmp, getValue(row, colType), wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
                    }
                    break;

                case ColumnTypeRim::DATE:
                case ColumnTypeRim::EXTENSION:
                    rectTmp.x     += gridGap_;
                    rectTmp.width -= gridGap_;
                    drawCellText(dc, rectTmp, getValue(row, colType), wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
                    break;
            }
        }
    }

    int getBestSize(wxDC& dc, size_t row, ColumnType colType) override
    {
        if (static_cast<ColumnTypeRim>(colType) == ColumnTypeRim::ITEM_PATH)
        {
            int bestSize = 0;

            if (const FileView::PathDrawInfo pdi = getDataView().getDrawInfo(row);
                pdi.fsObj)
            {
                const std::wstring& itemName = utfTo<std::wstring>(pdi.fsObj->getItemName<side>()); //don't care if FileSystemObject::isEmpty()
                std::vector<const ContainerObject*> parentComponents;

                switch (itemPathFormat_)
                {
                    case ItemPathFormat::FULL_PATH:
                        for (const FileSystemObject* fsObj2 = pdi.fsObj;;)
                        {
                            const ContainerObject& parent = fsObj2->parent();
                            parentComponents.push_back(&parent);

                            fsObj2 = dynamic_cast<const FolderPair*>(&parent);
                            if (!fsObj2)
                                break;
                        }
                        break;

                    case ItemPathFormat::RELATIVE_PATH:
                        for (const FileSystemObject* fsObj2 = pdi.fsObj;;)
                        {
                            const ContainerObject& parent = fsObj2->parent();

                            fsObj2 = dynamic_cast<const FolderPair*>(&parent);
                            if (!fsObj2)
                                break;
                            parentComponents.push_back(&parent);
                        }
                        break;

                    case ItemPathFormat::ITEM_NAME:
                        break;
                }

                /* Partitioning:
                    _______________________________________________________________________
                    | (gap | component name | gap | dash)* | icon | gap | item name | gap |
                    -----------------------------------------------------------------------        */
                for (const ContainerObject* parent : parentComponents)
                {
                    const FolderPair* folder = dynamic_cast<const FolderPair*>(parent);
                    const std::wstring& compName = folder ? utfTo<std::wstring>(folder->getItemName<side>()) :
                                                   AFS::getDisplayPath(parent->getAbstractPath<side>());

                    bestSize += gridGap_ + getTextExtentBuffered(dc, compName).GetWidth() + gridGap_ + compLineExtent_.GetWidth();
                }

                if (iconMgr_)
                {
                    if (parentComponents.empty())
                        bestSize += gridGap_;
                    bestSize += iconMgr_->refIconBuffer().getSize();
                }

                bestSize += gridGap_ + getTextExtentBuffered(dc, itemName).GetWidth() + gridGap_ /*for best size*/;
            }
            return bestSize;
        }
        else
        {
            const std::wstring cellValue = getValue(row, colType);
            return gridGap_ + dc.GetTextExtent(cellValue).GetWidth() + gridGap_;
        }
        // + 1 pix for cell border line ? -> not used anymore!
    }

    std::wstring getColumnLabel(ColumnType colType) const override
    {
        switch (static_cast<ColumnTypeRim>(colType))
        {
            case ColumnTypeRim::ITEM_PATH:
                switch (itemPathFormat_)
                {
                    case ItemPathFormat::FULL_PATH:
                        return _("Full path");
                    case ItemPathFormat::RELATIVE_PATH:
                        return _("Relative path");
                    case ItemPathFormat::ITEM_NAME:
                        return _("Item name");
                }
                assert(false);
                break;
            case ColumnTypeRim::SIZE:
                return _("Size");
            case ColumnTypeRim::DATE:
                return _("Date");
            case ColumnTypeRim::EXTENSION:
                return _("Extension");
        }
        //assert(false); may be ColumnType::NONE
        return std::wstring();
    }

    void renderColumnLabel(wxDC& dc, const wxRect& rect, ColumnType colType, bool enabled, bool highlighted) override
    {
        const wxRect rectInner = drawColumnLabelBackground(dc, rect, highlighted);
        wxRect rectRemain = rectInner;

        rectRemain.x     += getColumnGapLeft();
        rectRemain.width -= getColumnGapLeft();
        drawColumnLabelText(dc, rectRemain, getColumnLabel(colType), enabled);

        //draw sort marker
        if (auto sortInfo = getDataView().getSortInfo())
            if (const ColumnTypeRim* sortType = std::get_if<ColumnTypeRim>(&sortInfo->sortCol))
                if (*sortType == static_cast<ColumnTypeRim>(colType) && sortInfo->onLeft == (side == LEFT_SIDE))
                {
                    const wxBitmap sortMarker = getResourceImage(sortInfo->ascending ? "sort_ascending" : "sort_descending");
                    drawBitmapRtlNoMirror(dc, enabled ? sortMarker : sortMarker.ConvertToDisabled(), rectInner, wxALIGN_CENTER_HORIZONTAL);
                }
    }

    std::wstring getToolTip(size_t row, ColumnType colType) const override
    {
        std::wstring toolTip;

        if (const FileSystemObject* fsObj = getFsObject(row))
            if (!fsObj->isEmpty<side>())
            {
                toolTip = getDataView().getEffectiveFolderPairCount() > 1 ?
                          AFS::getDisplayPath(fsObj->getAbstractPath<side>()) :
                          utfTo<std::wstring>(fsObj->getRelativePath<side>());

                //path components should follow the app layout direction and are NOT a single piece of text!
                //caveat: add Bidi support only during rendering and not in getValue() or AFS::getDisplayPath(): e.g. support "open file in Explorer"
                assert(!contains(toolTip, slashBidi_) && !contains(toolTip, bslashBidi_));
                replace(toolTip, L"/",   slashBidi_);
                replace(toolTip, L"\\", bslashBidi_);

                visitFSObject(*fsObj, [](const FolderPair& folder) {},
                [&](const FilePair& file)
                {
                    toolTip += L'\n' +
                               _("Size:") + L' ' + formatFilesizeShort(file.getFileSize<side>()) + L'\n' +
                               _("Date:") + L' ' + formatUtcToLocalTime(file.getLastWriteTime<side>());
                },

                [&](const SymlinkPair& symlink)
                {
                    toolTip += L'\n' +
                               _("Date:") + L' ' + formatUtcToLocalTime(symlink.getLastWriteTime<side>());
                });
            }
        return toolTip;
    }

    struct IconInfo
    {
        enum IconType
        {
            EMPTY,
            FOLDER,
            ICON_PATH,
        };
        IconType type = EMPTY;
        const FileSystemObject* fsObj = nullptr; //only set if type != EMPTY
        bool drawAsLink = false;
    };

    IconInfo getIconInfo(size_t row) const //return ICON_FILE_FOLDER if row points to a folder
    {
        IconInfo out;

        if (const FileSystemObject* fsObj = getFsObject(row);
            fsObj && !fsObj->isEmpty<side>())
        {
            out.fsObj = fsObj;

            visitFSObject(*fsObj, [&](const FolderPair& folder)
            {
                out.type = IconInfo::FOLDER;
                out.drawAsLink = folder.isFollowedSymlink<side>();
            },

            [&](const FilePair& file)
            {
                out.type       = IconInfo::ICON_PATH;
                out.drawAsLink = file.isFollowedSymlink<side>() || hasLinkExtension(file.getItemName<side>());
            },

            [&](const SymlinkPair& symlink)
            {
                out.type       = IconInfo::ICON_PATH;
                out.drawAsLink = true;
            });
        }
        return out;
    }

    wxSize getTextExtentBuffered(wxDC& dc, const std::wstring& text)
    {
        auto& compExtentsBuf = getDataView().refCompExtentsBuf();
        //- shared between GridDataLeft/GridDataRight
        //- only used for parent component names and file names on view => should not grow "too big"
        //- cleaned up during FileView::setData()

        auto it = compExtentsBuf.find(text);
        if (it == compExtentsBuf.end())
            it = compExtentsBuf.emplace(text, dc.GetTextExtent(text)).first;
        return it->second;
    }

    const int gridGap_ = fastFromDIP(FILE_GRID_GAP_SIZE_DIP);
    const wxSize compLineExtent_{ fastFromDIP(5), fastFromDIP(1) };

    std::shared_ptr<IconManager> iconMgr_; //optional
    ItemPathFormat itemPathFormat_ = ItemPathFormat::FULL_PATH;

    std::vector<unsigned char> failedLoads_; //effectively a vector<bool> of size "number of rows"

    const std::wstring  slashBidi_ = (wxTheApp->GetLayoutDirection() == wxLayout_RightToLeft ? RTL_MARK : LTR_MARK) + std::wstring() + L"/";
    const std::wstring bslashBidi_ = (wxTheApp->GetLayoutDirection() == wxLayout_RightToLeft ? RTL_MARK : LTR_MARK) + std::wstring() + L"\\";
    //no need for LTR/RTL marks on both sides: text follows main direction if slash is between two strong characters with different directions
};


class GridDataLeft : public GridDataRim<LEFT_SIDE>
{
public:
    GridDataLeft(const SharedRef<FileView>& gridDataView, Grid& grid) : GridDataRim<LEFT_SIDE>(gridDataView, grid) {}

    void setNavigationMarker(std::unordered_set<const FileSystemObject*>&& markedFilesAndLinks,
                             std::unordered_set<const ContainerObject*>&& markedContainer)
    {
        markedFilesAndLinks_.swap(markedFilesAndLinks);
        markedContainer_    .swap(markedContainer);
    }

private:
    void renderRowBackgound(wxDC& dc, const wxRect& rect, size_t row, bool enabled, bool selected) override
    {
        GridDataRim<LEFT_SIDE>::renderRowBackgound(dc, rect, row, enabled, selected);

        //mark rows selected on overview panel:
        if (enabled && !selected)
        {
            const bool markRow = [&]
            {
                if (const FileSystemObject* fsObj = getFsObject(row))
                {
                    if (contains(markedFilesAndLinks_, fsObj)) //mark files/links directly
                        return true;

                    if (auto folder = dynamic_cast<const FolderPair*>(fsObj))
                        if (contains(markedContainer_, folder)) //mark folders which *are* the given ContainerObject*
                            return true;

                    //also mark all items with any matching ancestors
                    for (const FileSystemObject* fsObj2 = fsObj;;)
                    {
                        const ContainerObject& parent = fsObj2->parent();
                        if (contains(markedContainer_, &parent))
                            return true;

                        fsObj2 = dynamic_cast<const FolderPair*>(&parent);
                        if (!fsObj2)
                            break;
                    }
                }
                return false;
            }();

            if (markRow)
            {
                wxRect rectTmp = rect;
                rectTmp.width = fastFromDIP(15);
                rectTmp.x += rect.width - rectTmp.width;
                dc.GradientFillLinear(rectTmp, getColorSelectionGradientFrom(), getBackGroundColor(row), wxWEST);
            }
        }
    }

    std::unordered_set<const FileSystemObject*> markedFilesAndLinks_; //mark files/symlinks directly within a container
    std::unordered_set<const ContainerObject*> markedContainer_;      //mark full container including all child-objects
    //DO NOT DEREFERENCE!!!! NOT GUARANTEED TO BE VALID!!!
};


class GridDataRight : public GridDataRim<RIGHT_SIDE>
{
public:
    GridDataRight(const SharedRef<FileView>& gridDataView, Grid& grid) : GridDataRim<RIGHT_SIDE>(gridDataView, grid) {}
};

//########################################################################################################

class GridDataCenter : public GridDataBase
{
public:
    GridDataCenter(const SharedRef<FileView>& gridDataView, Grid& grid) :
        GridDataBase(grid, gridDataView),
        toolTip_(grid) {} //tool tip must not live longer than grid!

    void onSelectBegin()
    {
        selectionInProgress_ = true;
        refGrid().clearSelection(GridEventPolicy::DENY); //don't emit event, prevent recursion!
        toolTip_.hide(); //handle custom tooltip
    }

    void onSelectEnd(size_t rowFirst, size_t rowLast, HoverArea rowHover, ptrdiff_t clickInitRow)
    {
        refGrid().clearSelection(GridEventPolicy::DENY); //don't emit event, prevent recursion!

        //issue custom event
        if (selectionInProgress_) //don't process selections initiated by right-click
            if (rowFirst < rowLast && rowLast <= refGrid().getRowCount()) //empty? probably not in this context
                if (wxEvtHandler* evtHandler = refGrid().GetEventHandler())
                    switch (static_cast<HoverAreaCenter>(rowHover))
                    {
                        case HoverAreaCenter::CHECK_BOX:
                            if (const FileSystemObject* fsObj = getFsObject(clickInitRow))
                            {
                                const bool setIncluded = !fsObj->isActive();
                                CheckRowsEvent evt(rowFirst, rowLast, setIncluded);
                                evtHandler->ProcessEvent(evt);
                            }
                            break;
                        case HoverAreaCenter::DIR_LEFT:
                        {
                            SyncDirectionEvent evt(rowFirst, rowLast, SyncDirection::LEFT);
                            evtHandler->ProcessEvent(evt);
                        }
                        break;
                        case HoverAreaCenter::DIR_NONE:
                        {
                            SyncDirectionEvent evt(rowFirst, rowLast, SyncDirection::NONE);
                            evtHandler->ProcessEvent(evt);
                        }
                        break;
                        case HoverAreaCenter::DIR_RIGHT:
                        {
                            SyncDirectionEvent evt(rowFirst, rowLast, SyncDirection::RIGHT);
                            evtHandler->ProcessEvent(evt);
                        }
                        break;
                    }
        selectionInProgress_ = false;

        //update highlight_ and tooltip: on OS X no mouse movement event is generated after a mouse button click (unlike on Windows)
        wxPoint clientPos = refGrid().getMainWin().ScreenToClient(wxGetMousePosition());
        onMouseMovement(clientPos);
    }

    void onMouseMovement(const wxPoint& clientPos)
    {
        //manage block highlighting and custom tooltip
        if (!selectionInProgress_)
        {
            const wxPoint& topLeftAbs = refGrid().CalcUnscrolledPosition(clientPos);
            const size_t row = refGrid().getRowAtPos(topLeftAbs.y); //return -1 for invalid position, rowCount if one past the end
            const Grid::ColumnPosInfo cpi = refGrid().getColumnAtPos(topLeftAbs.x); //returns ColumnType::NONE if no column at x position!

            if (row < refGrid().getRowCount() && cpi.colType != ColumnType::NONE &&
                refGrid().getMainWin().GetClientRect().Contains(clientPos)) //cursor might have moved outside visible client area
                showToolTip(row, static_cast<ColumnTypeCenter>(cpi.colType), refGrid().getMainWin().ClientToScreen(clientPos));
            else
                toolTip_.hide();
        }
    }

    void onMouseLeave() //wxEVT_LEAVE_WINDOW does not respect mouse capture!
    {
        toolTip_.hide(); //handle custom tooltip
    }

    void highlightSyncAction(bool value) { highlightSyncAction_ = value; }

private:
    std::wstring getValue(size_t row, ColumnType colType) const override
    {
        if (const FileSystemObject* fsObj = getFsObject(row))
            switch (static_cast<ColumnTypeCenter>(colType))
            {
                case ColumnTypeCenter::CHECKBOX:
                    break;
                case ColumnTypeCenter::CMP_CATEGORY:
                    return getSymbol(fsObj->getCategory());
                case ColumnTypeCenter::SYNC_ACTION:
                    return getSymbol(fsObj->getSyncOperation());
            }
        return std::wstring();
    }

    void renderRowBackgound(wxDC& dc, const wxRect& rect, size_t row, bool enabled, bool selected) override
    {
        if (enabled && !selected)
        {
            if (const FileSystemObject* fsObj = getFsObject(row))
            {
                if (fsObj->isActive())
                    fillBackgroundDefaultColorAlternating(dc, rect, row % 2 == 0);
                else
                    clearArea(dc, rect, getColorNotActive());
            }
            else
                clearArea(dc, rect, wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW));
        }
        else
            GridData::renderRowBackgound(dc, rect, row, enabled, enabled && selected);
    }

    enum class HoverAreaCenter //each cell can be divided into four blocks concerning mouse selections
    {
        CHECK_BOX,
        DIR_LEFT,
        DIR_NONE,
        DIR_RIGHT
    };

    void renderCell(wxDC& dc, const wxRect& rect, size_t row, ColumnType colType, bool enabled, bool selected, HoverArea rowHover) override
    {
        auto drawHighlightBackground = [&](const FileSystemObject& fsObj, const wxColor& col)
        {
            if (enabled && !selected && fsObj.isActive()) //coordinate with renderRowBackgound()!
                clearArea(dc, rect, col);
        };

        switch (static_cast<ColumnTypeCenter>(colType))
        {
            case ColumnTypeCenter::CHECKBOX:
                if (const FileSystemObject* fsObj = getFsObject(row))
                {
                    const bool drawMouseHover = static_cast<HoverAreaCenter>(rowHover) == HoverAreaCenter::CHECK_BOX;

                    if (fsObj->isActive())
                        drawBitmapRtlNoMirror(dc, getResourceImage(drawMouseHover ? "checkbox_true_hover" : "checkbox_true"), rect, wxALIGN_CENTER);
                    else //default
                        drawBitmapRtlNoMirror(dc, getResourceImage(drawMouseHover ? "checkbox_false_hover" : "checkbox_false"), rect, wxALIGN_CENTER);
                }
                break;

            case ColumnTypeCenter::CMP_CATEGORY:
                if (const FileSystemObject* fsObj = getFsObject(row))
                {
                    if (!highlightSyncAction_)
                        drawHighlightBackground(*fsObj, getBackGroundColorCmpCategory(fsObj));

                    wxRect rectTmp = rect;
                    {
                        //draw notch on left side
                        if (notch_.GetHeight() != rectTmp.height)
                            notch_.Rescale(notch_.GetWidth(), rectTmp.height);

                        //wxWidgets screws up again and has wxALIGN_RIGHT off by one pixel! -> use wxALIGN_LEFT instead
                        const wxRect rectNotch(rectTmp.x + rectTmp.width - notch_.GetWidth(), rectTmp.y, notch_.GetWidth(), rectTmp.height);
                        drawBitmapRtlNoMirror(dc, notch_, rectNotch, wxALIGN_LEFT);
                        rectTmp.width -= notch_.GetWidth();
                    }

                    if (!highlightSyncAction_)
                        drawBitmapRtlMirror(dc, getCmpResultImage(fsObj->getCategory()), rectTmp, wxALIGN_CENTER, renderBufCmp_);
                    else if (fsObj->getCategory() != FILE_EQUAL) //don't show = in both middle columns
                        drawBitmapRtlMirror(dc, greyScale(getCmpResultImage(fsObj->getCategory())), rectTmp, wxALIGN_CENTER, renderBufCmp_);
                }
                break;

            case ColumnTypeCenter::SYNC_ACTION:
                if (const FileSystemObject* fsObj = getFsObject(row))
                {
                    if (highlightSyncAction_)
                        drawHighlightBackground(*fsObj, getBackGroundColorSyncAction(fsObj));

                    //synchronization preview
                    const auto rowHoverCenter = rowHover == HoverArea::NONE ? HoverAreaCenter::CHECK_BOX : static_cast<HoverAreaCenter>(rowHover);
                    switch (rowHoverCenter)
                    {
                        case HoverAreaCenter::DIR_LEFT:
                            drawBitmapRtlMirror(dc, getSyncOpImage(fsObj->testSyncOperation(SyncDirection::LEFT)), rect, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL, renderBufSync_);
                            break;
                        case HoverAreaCenter::DIR_NONE:
                            drawBitmapRtlNoMirror(dc, getSyncOpImage(fsObj->testSyncOperation(SyncDirection::NONE)), rect, wxALIGN_CENTER);
                            break;
                        case HoverAreaCenter::DIR_RIGHT:
                            drawBitmapRtlMirror(dc, getSyncOpImage(fsObj->testSyncOperation(SyncDirection::RIGHT)), rect, wxALIGN_RIGHT | wxALIGN_CENTER_VERTICAL, renderBufSync_);
                            break;
                        case HoverAreaCenter::CHECK_BOX:
                            if (highlightSyncAction_)
                                drawBitmapRtlMirror(dc, getSyncOpImage(fsObj->getSyncOperation()), rect, wxALIGN_CENTER, renderBufSync_);
                            else if (fsObj->getSyncOperation() != SO_EQUAL) //don't show = in both middle columns
                                drawBitmapRtlMirror(dc, greyScale(getSyncOpImage(fsObj->getSyncOperation())), rect, wxALIGN_CENTER, renderBufSync_);
                            break;
                    }
                }
                break;
        }
    }

    HoverArea getRowMouseHover(size_t row, ColumnType colType, int cellRelativePosX, int cellWidth) override
    {
        if (const FileSystemObject* const fsObj = getFsObject(row))
            switch (static_cast<ColumnTypeCenter>(colType))
            {
                case ColumnTypeCenter::CHECKBOX:
                case ColumnTypeCenter::CMP_CATEGORY:
                    return static_cast<HoverArea>(HoverAreaCenter::CHECK_BOX);

                case ColumnTypeCenter::SYNC_ACTION:
                    if (fsObj->getSyncOperation() == SO_EQUAL) //in sync-preview equal files shall be treated like a checkbox
                        return static_cast<HoverArea>(HoverAreaCenter::CHECK_BOX);
                    // cell:
                    //  -----------------------
                    // | left | middle | right|
                    //  -----------------------
                    if (0 <= cellRelativePosX)
                    {
                        if (cellRelativePosX < cellWidth / 3)
                            return static_cast<HoverArea>(HoverAreaCenter::DIR_LEFT);
                        else if (cellRelativePosX < 2 * cellWidth / 3)
                            return static_cast<HoverArea>(HoverAreaCenter::DIR_NONE);
                        else if  (cellRelativePosX < cellWidth)
                            return static_cast<HoverArea>(HoverAreaCenter::DIR_RIGHT);
                    }
                    break;
            }
        return HoverArea::NONE;
    }

    std::wstring getColumnLabel(ColumnType colType) const override
    {
        switch (static_cast<ColumnTypeCenter>(colType))
        {
            case ColumnTypeCenter::CHECKBOX:
                break;
            case ColumnTypeCenter::CMP_CATEGORY:
                return _("Category") + L" (F11)";
            case ColumnTypeCenter::SYNC_ACTION:
                return _("Action")   + L" (F11)";
        }
        return std::wstring();
    }

    std::wstring getToolTip(ColumnType colType) const override { return getColumnLabel(colType); }

    void renderColumnLabel(wxDC& dc, const wxRect& rect, ColumnType colType, bool enabled, bool highlighted) override
    {
        const auto colTypeCenter = static_cast<ColumnTypeCenter>(colType);

        const wxRect rectInner = drawColumnLabelBackground(dc, rect, highlighted && colTypeCenter != ColumnTypeCenter::CHECKBOX);

        wxBitmap colIcon;
        switch (colTypeCenter)
        {
            case ColumnTypeCenter::CHECKBOX:
                break;

            case ColumnTypeCenter::CMP_CATEGORY:
                colIcon = greyScaleIfDisabled(getResourceImage("compare_sicon"), !highlightSyncAction_);
                break;

            case ColumnTypeCenter::SYNC_ACTION:
                colIcon = greyScaleIfDisabled(getResourceImage("file_sync_sicon"), highlightSyncAction_);
                break;
        }

        if (colIcon.IsOk())
            drawBitmapRtlNoMirror(dc, enabled ? colIcon : colIcon.ConvertToDisabled(), rectInner, wxALIGN_CENTER);

        //draw sort marker
        if (auto sortInfo = getDataView().getSortInfo())
            if (const ColumnTypeCenter* sortType = std::get_if<ColumnTypeCenter>(&sortInfo->sortCol))
                if (*sortType == colTypeCenter)
                {
                    const int gapLeft = (rectInner.width + colIcon.GetWidth()) / 2;
                    wxRect rectRemain = rectInner;
                    rectRemain.x     += gapLeft;
                    rectRemain.width -= gapLeft;

                    const wxBitmap sortMarker = getResourceImage(sortInfo->ascending ? "sort_ascending" : "sort_descending");
                    drawBitmapRtlNoMirror(dc, enabled ? sortMarker : sortMarker.ConvertToDisabled(), rectRemain, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
                }
    }

    static wxColor getBackGroundColorSyncAction(const FileSystemObject* fsObj)
    {
        if (fsObj)
        {
            if (!fsObj->isActive())
                return getColorNotActive();

            switch (fsObj->getSyncOperation()) //evaluate comparison result and sync direction
            {
                case SO_DO_NOTHING:
                    return getColorNotActive();
                case SO_EQUAL:
                    break; //usually white

                case SO_CREATE_NEW_LEFT:
                case SO_OVERWRITE_LEFT:
                case SO_DELETE_LEFT:
                case SO_MOVE_LEFT_FROM:
                case SO_MOVE_LEFT_TO:
                case SO_COPY_METADATA_TO_LEFT:
                    return getColorSyncBlue();

                case SO_CREATE_NEW_RIGHT:
                case SO_OVERWRITE_RIGHT:
                case SO_DELETE_RIGHT:
                case SO_MOVE_RIGHT_FROM:
                case SO_MOVE_RIGHT_TO:
                case SO_COPY_METADATA_TO_RIGHT:
                    return getColorSyncGreen();

                case SO_UNRESOLVED_CONFLICT:
                    return getColorYellow();
            }
        }
        return wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW);
    }

    static wxColor getBackGroundColorCmpCategory(const FileSystemObject* fsObj)
    {
        if (fsObj)
        {
            if (!fsObj->isActive())
                return getColorNotActive();

            switch (fsObj->getCategory())
            {
                case FILE_LEFT_SIDE_ONLY:
                case FILE_LEFT_NEWER:
                    return getColorSyncBlue(); //COLOR_CMP_BLUE;

                case FILE_RIGHT_SIDE_ONLY:
                case FILE_RIGHT_NEWER:
                    return getColorSyncGreen(); //COLOR_CMP_GREEN;

                case FILE_DIFFERENT_CONTENT:
                    return getColorCmpRed();
                case FILE_EQUAL:
                    break; //usually white
                case FILE_CONFLICT:
                case FILE_DIFFERENT_METADATA: //= sub-category of equal, but hint via background that sync direction follows conflict-setting
                    return getColorYellow();
                    //return getColorYellowLight();
            }
        }
        return wxSystemSettings::GetColour(wxSYS_COLOUR_WINDOW);
    }

    void showToolTip(size_t row, ColumnTypeCenter colType, wxPoint posScreen)
    {
        if (const FileSystemObject* fsObj = getFsObject(row))
        {
            switch (colType)
            {
                case ColumnTypeCenter::CHECKBOX:
                case ColumnTypeCenter::CMP_CATEGORY:
                {
                    const char* imageName = [&]
                    {
                        const CompareFileResult cmpRes = fsObj->getCategory();
                        switch (cmpRes)
                            {
                            //*INDENT-OFF*
                            case FILE_LEFT_SIDE_ONLY:     return "cat_left_only";
                            case FILE_RIGHT_SIDE_ONLY:    return "cat_right_only";
                            case FILE_LEFT_NEWER:         return "cat_left_newer";
                            case FILE_RIGHT_NEWER:        return "cat_right_newer";
                            case FILE_DIFFERENT_CONTENT:  return "cat_different";
                            case FILE_EQUAL:
                            case FILE_DIFFERENT_METADATA: return "cat_equal"; //= sub-category of equal
case FILE_CONFLICT:           return "cat_conflict";
//*INDENT-ON*
                        }
                        assert(false);
                        return "";
                    }();
                    const auto& img = mirrorIfRtl(getResourceImage(imageName));
                    toolTip_.show(getCategoryDescription(*fsObj), posScreen, &img);
                }
                break;

            case ColumnTypeCenter::SYNC_ACTION:
            {
                const char* imageName = [&]
                {
                    const SyncOperation syncOp = fsObj->getSyncOperation();
                    switch (syncOp)
                            {
                            //*INDENT-OFF*
                            case SO_CREATE_NEW_LEFT:        return "so_create_left";
                            case SO_CREATE_NEW_RIGHT:       return "so_create_right";
                            case SO_DELETE_LEFT:            return "so_delete_left";
                            case SO_DELETE_RIGHT:           return "so_delete_right";
                            case SO_MOVE_LEFT_FROM:         return "so_move_left_source";
                            case SO_MOVE_LEFT_TO:           return "so_move_left_target";
                            case SO_MOVE_RIGHT_FROM:        return "so_move_right_source";
                            case SO_MOVE_RIGHT_TO:          return "so_move_right_target";
                            case SO_OVERWRITE_LEFT:         return "so_update_left";
                            case SO_OVERWRITE_RIGHT:        return "so_update_right";
                            case SO_COPY_METADATA_TO_LEFT:  return "so_move_left";
                            case SO_COPY_METADATA_TO_RIGHT: return "so_move_right";
                            case SO_DO_NOTHING:             return "so_none";
                            case SO_EQUAL:                  return "cat_equal";
    case SO_UNRESOLVED_CONFLICT:    return "cat_conflict";
    //*INDENT-ON*
                    };
                    assert(false);
                    return "";
                }();
                const auto& img = mirrorIfRtl(getResourceImage(imageName));
                toolTip_.show(getSyncOpDescription(*fsObj), posScreen, &img);
            }
            break;
    }
}
else
    toolTip_.hide(); //if invalid row...
    }

    bool highlightSyncAction_ = false;
    bool selectionInProgress_ = false;

    std::optional<wxBitmap> renderBufCmp_; //avoid costs of recreating this temporary variable
    std::optional<wxBitmap> renderBufSync_;
    Tooltip toolTip_;
    wxImage notch_ = getResourceImage("notch").ConvertToImage();
};

//########################################################################################################

const wxEventType EVENT_ALIGN_SCROLLBARS = wxNewEventType();

class GridEventManager : private wxEvtHandler
{
public:
    GridEventManager(Grid& gridL,
             Grid& gridC,
             Grid& gridR,
             GridDataCenter& provCenter) :
gridL_(gridL), gridC_(gridC), gridR_(gridR),
provCenter_(provCenter)
    {
gridL_.Connect(EVENT_GRID_COL_RESIZE, GridColumnResizeEventHandler(GridEventManager::onResizeColumnL), nullptr, this);
gridR_.Connect(EVENT_GRID_COL_RESIZE, GridColumnResizeEventHandler(GridEventManager::onResizeColumnR), nullptr, this);

gridL_.getMainWin().Connect(wxEVT_KEY_DOWN, wxKeyEventHandler(GridEventManager::onKeyDownL), nullptr, this);
gridC_.getMainWin().Connect(wxEVT_KEY_DOWN, wxKeyEventHandler(GridEventManager::onKeyDownC), nullptr, this);
gridR_.getMainWin().Connect(wxEVT_KEY_DOWN, wxKeyEventHandler(GridEventManager::onKeyDownR), nullptr, this);

gridC_.getMainWin().Connect(wxEVT_MOTION,       wxMouseEventHandler(GridEventManager::onCenterMouseMovement), nullptr, this);
gridC_.getMainWin().Connect(wxEVT_LEAVE_WINDOW, wxMouseEventHandler(GridEventManager::onCenterMouseLeave   ), nullptr, this);

gridC_.Connect(EVENT_GRID_MOUSE_LEFT_DOWN, GridClickEventHandler (GridEventManager::onCenterSelectBegin), nullptr, this);
gridC_.Connect(EVENT_GRID_SELECT_RANGE,    GridSelectEventHandler(GridEventManager::onCenterSelectEnd  ), nullptr, this);

//clear selection of other grid when selecting on
gridL_.Connect(EVENT_GRID_SELECT_RANGE, GridSelectEventHandler(GridEventManager::onGridSelectionL), nullptr, this);
gridR_.Connect(EVENT_GRID_SELECT_RANGE, GridSelectEventHandler(GridEventManager::onGridSelectionR), nullptr, this);

//parallel grid scrolling: do NOT use DoPrepareDC() to align grids! GDI resource leak! Use regular paint event instead:
gridL_.getMainWin().Connect(wxEVT_PAINT, wxEventHandler(GridEventManager::onPaintGridL), nullptr, this);
gridC_.getMainWin().Connect(wxEVT_PAINT, wxEventHandler(GridEventManager::onPaintGridC), nullptr, this);
gridR_.getMainWin().Connect(wxEVT_PAINT, wxEventHandler(GridEventManager::onPaintGridR), nullptr, this);

auto connectGridAccess = [&](Grid& grid, wxObjectEventFunction func)
{
    grid.Connect(wxEVT_SCROLLWIN_TOP,        func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_BOTTOM,     func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_LINEUP,     func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_LINEDOWN,   func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_PAGEUP,     func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_PAGEDOWN,   func, nullptr, this);
    grid.Connect(wxEVT_SCROLLWIN_THUMBTRACK, func, nullptr, this);
    //wxEVT_KILL_FOCUS -> there's no need to reset "scrollMaster"
    //wxEVT_SET_FOCUS -> not good enough:
    //e.g.: left grid has input, right grid is "scrollMaster" due to dragging scroll thumb via mouse.
    //=> Next keyboard input on left does *not* emit focus change event, but still "scrollMaster" needs to change
    //=> hook keyboard input instead of focus event:
    grid.getMainWin().Connect(wxEVT_CHAR,     func, nullptr, this);
    grid.getMainWin().Connect(wxEVT_KEY_UP,   func, nullptr, this);
    grid.getMainWin().Connect(wxEVT_KEY_DOWN, func, nullptr, this);

    grid.getMainWin().Connect(wxEVT_LEFT_DOWN,   func, nullptr, this);
    grid.getMainWin().Connect(wxEVT_LEFT_DCLICK, func, nullptr, this);
    grid.getMainWin().Connect(wxEVT_RIGHT_DOWN,  func, nullptr, this);
    //grid.getMainWin().Connect(wxEVT_MOUSEWHEEL, func, nullptr, this); -> should be covered by wxEVT_SCROLLWIN_*
};
connectGridAccess(gridL_, wxEventHandler(GridEventManager::onGridAccessL)); //
connectGridAccess(gridC_, wxEventHandler(GridEventManager::onGridAccessC)); //connect *after* onKeyDown() in order to receive callback *before*!!!
connectGridAccess(gridR_, wxEventHandler(GridEventManager::onGridAccessR)); //

Connect(EVENT_ALIGN_SCROLLBARS, wxEventHandler(GridEventManager::onAlignScrollBars), NULL, this);
    }

    ~GridEventManager()
    {
//assert(!scrollbarUpdatePending_); => false-positives: e.g. start ffs, right-click on grid, close by clicking X
    }

    void setScrollMaster(const Grid& grid) { scrollMaster_ = &grid; }

private:
    void onCenterSelectBegin(GridClickEvent& event)
    {
provCenter_.onSelectBegin();
event.Skip();
    }

    void onCenterSelectEnd(GridSelectEvent& event)
    {
if (event.positive_)
{
    if (event.mouseClick_)
        provCenter_.onSelectEnd(event.rowFirst_, event.rowLast_, event.mouseClick_->hoverArea_, event.mouseClick_->row_);
    else
        provCenter_.onSelectEnd(event.rowFirst_, event.rowLast_, HoverArea::NONE, -1);
}
event.Skip();
    }

    void onCenterMouseMovement(wxMouseEvent& event)
    {
provCenter_.onMouseMovement(event.GetPosition());
event.Skip();
    }

    void onCenterMouseLeave(wxMouseEvent& event)
    {
provCenter_.onMouseLeave();
event.Skip();
    }

    void onGridSelectionL(GridSelectEvent& event) { onGridSelection(gridL_, gridR_); event.Skip(); }
    void onGridSelectionR(GridSelectEvent& event) { onGridSelection(gridR_, gridL_); event.Skip(); }

    void onGridSelection(const Grid& grid, Grid& other)
    {
if (!wxGetKeyState(WXK_CONTROL)) //clear other grid unless user is holding CTRL
    other.clearSelection(GridEventPolicy::DENY); //don't emit event, prevent recursion!
    }

    void onKeyDownL(wxKeyEvent& event) {  onKeyDown(event, gridL_); }
    void onKeyDownC(wxKeyEvent& event) {  onKeyDown(event, gridC_); }
    void onKeyDownR(wxKeyEvent& event) {  onKeyDown(event, gridR_); }

    void onKeyDown(wxKeyEvent& event, const Grid& grid)
    {
int keyCode = event.GetKeyCode();
if (grid.GetLayoutDirection() == wxLayout_RightToLeft)
{
    if (keyCode == WXK_LEFT || keyCode == WXK_NUMPAD_LEFT)
        keyCode = WXK_RIGHT;
    else if (keyCode == WXK_RIGHT || keyCode == WXK_NUMPAD_RIGHT)
        keyCode = WXK_LEFT;
}

//skip middle component when navigating via keyboard
const size_t row = grid.getGridCursor();

if (event.ShiftDown())
    ;
else if (event.ControlDown())
    ;
else
    switch (keyCode)
    {
        case WXK_LEFT:
        case WXK_NUMPAD_LEFT:
            gridL_.setGridCursor(row, GridEventPolicy::ALLOW);
            gridL_.SetFocus();
            //since key event is likely originating from right grid, we need to set scrollMaster manually!
            scrollMaster_ = &gridL_; //onKeyDown is called *after* onGridAccessL()!
            return; //swallow event

        case WXK_RIGHT:
        case WXK_NUMPAD_RIGHT:
            gridR_.setGridCursor(row, GridEventPolicy::ALLOW);
            gridR_.SetFocus();
            scrollMaster_ = &gridR_;
            return; //swallow event
    }

event.Skip();
    }

    void onResizeColumnL(GridColumnResizeEvent& event) { resizeOtherSide(gridL_, gridR_, event.colType_, event.offset_); }
    void onResizeColumnR(GridColumnResizeEvent& event) { resizeOtherSide(gridR_, gridL_, event.colType_, event.offset_); }

    void resizeOtherSide(const Grid& src, Grid& trg, ColumnType type, int offset)
    {
//find stretch factor of resized column: type is unique due to makeConsistent()!
std::vector<Grid::ColAttributes> cfgSrc = src.getColumnConfig();
auto it = std::find_if(cfgSrc.begin(), cfgSrc.end(), [&](Grid::ColAttributes& ca) { return ca.type == type; });
if (it == cfgSrc.end())
    return;
const int stretchSrc = it->stretch;

//we do not propagate resizings on stretched columns to the other side: awkward user experience
if (stretchSrc > 0)
    return;

//apply resized offset to other side, but only if stretch factors match!
std::vector<Grid::ColAttributes> cfgTrg = trg.getColumnConfig();
for (Grid::ColAttributes& ca : cfgTrg)
    if (ca.type == type && ca.stretch == stretchSrc)
        ca.offset = offset;
trg.setColumnConfig(cfgTrg);
    }

    void onGridAccessL(wxEvent& event) { scrollMaster_ = &gridL_; event.Skip(); }
    void onGridAccessC(wxEvent& event) { scrollMaster_ = &gridC_; event.Skip(); }
    void onGridAccessR(wxEvent& event) { scrollMaster_ = &gridR_; event.Skip(); }

    void onPaintGridL(wxEvent& event) { onPaintGrid(gridL_); event.Skip(); }
    void onPaintGridC(wxEvent& event) { onPaintGrid(gridC_); event.Skip(); }
    void onPaintGridR(wxEvent& event) { onPaintGrid(gridR_); event.Skip(); }

    void onPaintGrid(const Grid& grid)
    {
//align scroll positions of all three grids *synchronously* during paint event! (wxGTK has visible delay when this is done asynchronously, no delay on Windows)

//determine lead grid
const Grid* lead = nullptr;
Grid* follow1    = nullptr;
Grid* follow2    = nullptr;
auto setGrids = [&](const Grid& l, Grid& f1, Grid& f2) { lead = &l; follow1 = &f1; follow2 = &f2; };

if (&gridC_ == scrollMaster_)
    setGrids(gridC_, gridL_, gridR_);
else if (&gridR_ == scrollMaster_)
    setGrids(gridR_, gridL_, gridC_);
else //default: left panel
    setGrids(gridL_, gridC_, gridR_);

//align other grids only while repainting the lead grid to avoid scrolling and updating a grid at the same time!
if (lead == &grid)
{
    auto scroll = [](Grid& target, int y) //support polling
    {
        //scroll vertically only - scrolling horizontally becomes annoying if left and right sides have different widths;
        //e.g. h-scroll on left would be undone when scrolling vertically on right which doesn't have a h-scrollbar
        int yOld = 0;
        target.GetViewStart(nullptr, &yOld);
        if (yOld != y)
            target.Scroll(-1, y); //empirical test Windows/Ubuntu: this call does NOT trigger a wxEVT_SCROLLWIN event, which would incorrectly set "scrollMaster" to "&target"!
        //CAVEAT: wxScrolledWindow::Scroll() internally calls wxWindow::Update(), leading to immediate WM_PAINT handling in the target grid!
        //        an this while we're still in our WM_PAINT handler! => no recursion, fine (hopefully)
    };
    int y = 0;
    lead->GetViewStart(nullptr, &y);
    scroll(*follow1, y);
    scroll(*follow2, y);
}

//harmonize placement of horizontal scrollbar to avoid grids getting out of sync!
//since this affects the grid that is currently repainted as well, we do work asynchronously!
if (!scrollbarUpdatePending_) //send one async event at most, else they may accumulate and create perf issues, see grid.cpp
{
    scrollbarUpdatePending_ = true;
    wxCommandEvent alignEvent(EVENT_ALIGN_SCROLLBARS);
    AddPendingEvent(alignEvent); //waits until next idle event - may take up to a second if the app is busy on wxGTK!
}
    }

    void onAlignScrollBars(wxEvent& event)
    {
assert(scrollbarUpdatePending_);
ZEN_ON_SCOPE_EXIT(scrollbarUpdatePending_ = false);

auto needsHorizontalScrollbars = [](const Grid& grid) -> bool
{
    const wxWindow& mainWin = grid.getMainWin();
    return mainWin.GetVirtualSize().GetWidth() > mainWin.GetClientSize().GetWidth();
    //assuming Grid::updateWindowSizes() does its job well, this should suffice!
    //CAVEAT: if horizontal and vertical scrollbar are circular dependent from each other
    //(h-scrollbar is shown due to v-scrollbar consuming horizontal width, etc...)
    //while in fact both are NOT needed, this special case results in a bogus need for scrollbars!
    //see https://sourceforge.net/tracker/?func=detail&aid=3514183&group_id=234430&atid=1093083
    // => since we're outside the Grid abstraction, we should not duplicate code to handle this special case as it seems to be insignificant
};

Grid::ScrollBarStatus sbStatusX = needsHorizontalScrollbars(gridL_) ||
                                  needsHorizontalScrollbars(gridR_) ?
                                  Grid::SB_SHOW_ALWAYS : Grid::SB_SHOW_NEVER;
gridL_.showScrollBars(sbStatusX, Grid::SB_SHOW_NEVER);
gridC_.showScrollBars(sbStatusX, Grid::SB_SHOW_NEVER);
gridR_.showScrollBars(sbStatusX, Grid::SB_SHOW_AUTOMATIC);
    }

    Grid& gridL_;
    Grid& gridC_;
    Grid& gridR_;

    const Grid* scrollMaster_ = nullptr; //for address check only; this needn't be the grid having focus!
    //e.g. mouse wheel events should set window under cursor as scrollMaster, but *not* change focus

    GridDataCenter& provCenter_;
    bool scrollbarUpdatePending_ = false;
};
}

//########################################################################################################

void filegrid::init(Grid& gridLeft, Grid& gridCenter, Grid& gridRight)
{
    const auto gridDataView = makeSharedRef<FileView>();

    auto provLeft_   = std::make_shared<GridDataLeft  >(gridDataView, gridLeft);
    auto provCenter_ = std::make_shared<GridDataCenter>(gridDataView, gridCenter);
    auto provRight_  = std::make_shared<GridDataRight >(gridDataView, gridRight);

    gridLeft  .setDataProvider(provLeft_);   //data providers reference grid =>
    gridCenter.setDataProvider(provCenter_); //ownership must belong *exclusively* to grid!
    gridRight .setDataProvider(provRight_);

    auto evtMgr = std::make_shared<GridEventManager>(gridLeft, gridCenter, gridRight, *provCenter_);
    provLeft_  ->holdOwnership(evtMgr);
    provCenter_->holdOwnership(evtMgr);
    provRight_ ->holdOwnership(evtMgr);

    gridCenter.enableColumnMove  (false);
    gridCenter.enableColumnResize(false);

    gridCenter.showRowLabel(false);
    gridRight .showRowLabel(false);

    //gridLeft  .showScrollBars(Grid::SB_SHOW_AUTOMATIC, Grid::SB_SHOW_NEVER); -> redundant: configuration happens in GridEventManager::onAlignScrollBars()
    //gridCenter.showScrollBars(Grid::SB_SHOW_NEVER,     Grid::SB_SHOW_NEVER);

    const int widthCheckbox = getResourceImage("checkbox_true").GetWidth() + fastFromDIP(3);
    const int widthCategory = 2 * getResourceImage("sort_ascending").GetWidth() + getResourceImage("cat_left_only_sicon").GetWidth() + getResourceImage("notch").GetWidth();
    const int widthAction   = 3 * getResourceImage("so_create_left_sicon").GetWidth();
    gridCenter.SetSize(widthCategory + widthCheckbox + widthAction, -1);

    gridCenter.setColumnConfig(
    {
{ static_cast<ColumnType>(ColumnTypeCenter::CHECKBOX    ), widthCheckbox, 0, true },
{ static_cast<ColumnType>(ColumnTypeCenter::CMP_CATEGORY), widthCategory, 0, true },
{ static_cast<ColumnType>(ColumnTypeCenter::SYNC_ACTION ), widthAction,   0, true },
    });
}


FileView& filegrid::getDataView(Grid& grid)
{
    if (auto* prov = dynamic_cast<GridDataBase*>(grid.getDataProvider()))
return prov->getDataView();

    throw std::runtime_error("filegrid was not initialized! " + std::string(__FILE__) + ':' + numberTo<std::string>(__LINE__));
}


namespace
{
class IconUpdater : private wxEvtHandler //update file icons periodically: use SINGLE instance to coordinate left and right grids in parallel
{
public:
    IconUpdater(GridDataLeft& provLeft, GridDataRight& provRight, IconBuffer& iconBuffer) : provLeft_(provLeft), provRight_(provRight), iconBuffer_(iconBuffer)
    {
timer_.Connect(wxEVT_TIMER, wxEventHandler(IconUpdater::loadIconsAsynchronously), nullptr, this);
    }

    void start() { if (!timer_.IsRunning()) timer_.Start(100); } //timer interval in [ms]
    //don't check too often! give worker thread some time to fetch data

private:
    void stop() { if (timer_.IsRunning()) timer_.Stop(); }

    void loadIconsAsynchronously(wxEvent& event) //loads all (not yet) drawn icons
    {
std::vector<std::pair<ptrdiff_t, AbstractPath>> prefetchLoad;
provLeft_ .getUnbufferedIconsForPreload(prefetchLoad);
provRight_.getUnbufferedIconsForPreload(prefetchLoad);

//make sure least-important prefetch rows are inserted first into workload (=> processed last)
//priority index nicely considers both grids at the same time!
std::sort(prefetchLoad.begin(), prefetchLoad.end(), [](const auto& lhs, const auto& rhs) { return lhs.first < rhs.first; });

//last inserted items are processed first in icon buffer:
std::vector<AbstractPath> newLoad;
for (const auto& [priority, filePath] : prefetchLoad)
    newLoad.push_back(filePath);

provRight_.updateNewAndGetUnbufferedIcons(newLoad);
provLeft_ .updateNewAndGetUnbufferedIcons(newLoad);

iconBuffer_.setWorkload(newLoad);

if (newLoad.empty()) //let's only pay for IconUpdater while needed
    stop();
    }

    GridDataLeft&  provLeft_;
    GridDataRight& provRight_;
    IconBuffer& iconBuffer_;
    wxTimer timer_;
};


//resolve circular linker dependencies
inline
void IconManager::startIconUpdater() { if (iconUpdater_) iconUpdater_->start(); }
}


void filegrid::setupIcons(Grid& gridLeft, Grid& gridCenter, Grid& gridRight, bool show, IconBuffer::IconSize sz)
{
    auto* provLeft  = dynamic_cast<GridDataLeft*>(gridLeft .getDataProvider());
    auto* provRight = dynamic_cast<GridDataRight*>(gridRight.getDataProvider());

    if (provLeft && provRight)
    {
int iconHeight = 0;
if (show)
{
    auto iconMgr = std::make_shared<IconManager>(*provLeft, *provRight, sz);
    provLeft ->setIconManager(iconMgr);
    provRight->setIconManager(iconMgr);
    iconHeight = iconMgr->refIconBuffer().getSize();
}
else
{
    provLeft ->setIconManager(nullptr);
    provRight->setIconManager(nullptr);
    iconHeight = IconBuffer::getSize(IconBuffer::SIZE_SMALL);
}

const int newRowHeight = std::max(iconHeight, gridLeft.getMainWin().GetCharHeight()) + fastFromDIP(1); //add some space

gridLeft  .setRowHeight(newRowHeight);
gridCenter.setRowHeight(newRowHeight);
gridRight .setRowHeight(newRowHeight);
    }
    else
assert(false);
}


void filegrid::setItemPathForm(Grid& grid, ItemPathFormat fmt)
{
    if (auto* provLeft  = dynamic_cast<GridDataLeft*>(grid.getDataProvider()))
provLeft->setItemPathForm(fmt);
    else if (auto* provRight = dynamic_cast<GridDataRight*>(grid.getDataProvider()))
provRight->setItemPathForm(fmt);
    else
assert(false);
    grid.Refresh();
}


void filegrid::refresh(Grid& gridLeft, Grid& gridCenter, Grid& gridRight)
{
    gridLeft  .Refresh();
    gridCenter.Refresh();
    gridRight .Refresh();
}


void filegrid::setScrollMaster(Grid& grid)
{
    if (auto prov = dynamic_cast<GridDataBase*>(grid.getDataProvider()))
if (auto evtMgr = prov->getEventManager())
{
    evtMgr->setScrollMaster(grid);
    return;
}
    assert(false);
}


void filegrid::setNavigationMarker(Grid& gridLeft,
                           std::unordered_set<const FileSystemObject*>&& markedFilesAndLinks,
                           std::unordered_set<const ContainerObject*>&& markedContainer)
{
    if (auto provLeft = dynamic_cast<GridDataLeft*>(gridLeft.getDataProvider()))
provLeft->setNavigationMarker(std::move(markedFilesAndLinks), std::move(markedContainer));
    else
assert(false);
    gridLeft.Refresh();
}


void filegrid::highlightSyncAction(Grid& gridCenter, bool value)
{
    if (auto provCenter = dynamic_cast<GridDataCenter*>(gridCenter.getDataProvider()))
provCenter->highlightSyncAction(value);
    else
assert(false);
    gridCenter.Refresh();
}


wxBitmap fff::getSyncOpImage(SyncOperation syncOp)
{
    switch (syncOp) //evaluate comparison result and sync direction
    {
        //*INDENT-OFF*
        case SO_CREATE_NEW_LEFT:        return getResourceImage("so_create_left_sicon");
        case SO_CREATE_NEW_RIGHT:       return getResourceImage("so_create_right_sicon");
        case SO_DELETE_LEFT:            return getResourceImage("so_delete_left_sicon");
        case SO_DELETE_RIGHT:           return getResourceImage("so_delete_right_sicon");
        case SO_MOVE_LEFT_FROM:         return getResourceImage("so_move_left_source_sicon");
        case SO_MOVE_LEFT_TO:           return getResourceImage("so_move_left_target_sicon");
        case SO_MOVE_RIGHT_FROM:        return getResourceImage("so_move_right_source_sicon");
        case SO_MOVE_RIGHT_TO:          return getResourceImage("so_move_right_target_sicon");
        case SO_OVERWRITE_LEFT:         return getResourceImage("so_update_left_sicon");
        case SO_OVERWRITE_RIGHT:        return getResourceImage("so_update_right_sicon");
        case SO_COPY_METADATA_TO_LEFT:  return getResourceImage("so_move_left_sicon");
        case SO_COPY_METADATA_TO_RIGHT: return getResourceImage("so_move_right_sicon");
        case SO_DO_NOTHING:             return getResourceImage("so_none_sicon");
        case SO_EQUAL:                  return getResourceImage("cat_equal_sicon");
case SO_UNRESOLVED_CONFLICT:    return getResourceImage("cat_conflict_small");
//*INDENT-ON*
    }
    assert(false);
    return wxNullBitmap;
}


wxBitmap fff::getCmpResultImage(CompareFileResult cmpResult)
{
    switch (cmpResult)
    {
        //*INDENT-OFF*
        case FILE_LEFT_SIDE_ONLY:     return getResourceImage("cat_left_only_sicon");
        case FILE_RIGHT_SIDE_ONLY:    return getResourceImage("cat_right_only_sicon");
        case FILE_LEFT_NEWER:         return getResourceImage("cat_left_newer_sicon");
        case FILE_RIGHT_NEWER:        return getResourceImage("cat_right_newer_sicon");
        case FILE_DIFFERENT_CONTENT:  return getResourceImage("cat_different_sicon");
        case FILE_EQUAL: 
        case FILE_DIFFERENT_METADATA: return getResourceImage("cat_equal_sicon"); //= sub-category of equal
case FILE_CONFLICT:           return getResourceImage("cat_conflict_small");
//*INDENT-ON*
    }
    assert(false);
    return wxNullBitmap;
}
