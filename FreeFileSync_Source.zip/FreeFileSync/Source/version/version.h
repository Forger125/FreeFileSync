#ifndef VERSION_HEADER_434343489702544325
#define VERSION_HEADER_434343489702544325

namespace fff
{
const char ffsVersion[] = "11.16"; //internal linkage!
const char FFS_VERSION_SEPARATOR = '.';
}

#endif
